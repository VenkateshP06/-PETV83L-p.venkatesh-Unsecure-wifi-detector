import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
import re
import threading
import time
from datetime import datetime
import json
import os
import platform
import sys

class CrossPlatformWiFiScanner:
    def __init__(self, root):
        self.root = root
        self.root.title("WiFi Security Scanner - Cross Platform")
        self.root.geometry("900x700")
        self.root.configure(bg='#f0f0f0')
        
        # Platform detection
        self.platform = platform.system().lower()
        
        # Data storage
        self.networks = []
        self.scanning = False
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main frame
        main_frame = tk.Frame(self.root, bg='#f0f0f0')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Title with platform info
        title_text = f"WiFi Security Scanner - {self.platform.title()}"
        title_label = tk.Label(
            main_frame, 
            text=title_text, 
            font=("Arial", 18, "bold"),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        title_label.pack(pady=(0, 10))
        
        # Platform info
        platform_info = tk.Label(
            main_frame,
            text=f"Detected Platform: {self.platform.title()}",
            font=("Arial", 10),
            bg='#f0f0f0',
            fg='#7f8c8d'
        )
        platform_info.pack(pady=(0, 20))
        
        # Control frame
        control_frame = tk.Frame(main_frame, bg='#f0f0f0')
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Scan button
        self.scan_button = tk.Button(
            control_frame,
            text="Start Scan",
            command=self.start_scan,
            bg='#3498db',
            fg='white',
            font=("Arial", 12, "bold"),
            relief=tk.FLAT,
            padx=20,
            pady=10
        )
        self.scan_button.pack(side=tk.LEFT, padx=(0, 10))
        
        # Status label
        self.status_label = tk.Label(
            control_frame,
            text="Ready to scan",
            font=("Arial", 10),
            bg='#f0f0f0',
            fg='#7f8c8d'
        )
        self.status_label.pack(side=tk.LEFT, padx=(10, 0))
        
        # Progress bar
        self.progress = ttk.Progressbar(
            control_frame,
            mode='indeterminate',
            length=200
        )
        self.progress.pack(side=tk.RIGHT, padx=(0, 10))
        
        # Results frame
        results_frame = tk.Frame(main_frame, bg='white', relief=tk.RAISED, bd=1)
        results_frame.pack(fill=tk.BOTH, expand=True)
        
        # Treeview for results
        columns = ('SSID', 'Security', 'Signal', 'Channel', 'Risk Level', 'BSSID')
        self.tree = ttk.Treeview(results_frame, columns=columns, show='headings', height=15)
        
        # Configure columns
        self.tree.heading('SSID', text='Network Name (SSID)')
        self.tree.heading('Security', text='Security Protocol')
        self.tree.heading('Signal', text='Signal Strength')
        self.tree.heading('Channel', text='Channel')
        self.tree.heading('Risk Level', text='Risk Level')
        self.tree.heading('BSSID', text='BSSID/MAC')
        
        self.tree.column('SSID', width=180)
        self.tree.column('Security', width=120)
        self.tree.column('Signal', width=100)
        self.tree.column('Channel', width=80)
        self.tree.column('Risk Level', width=100)
        self.tree.column('BSSID', width=150)
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(results_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Summary frame
        summary_frame = tk.Frame(main_frame, bg='#f0f0f0')
        summary_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.summary_label = tk.Label(
            summary_frame,
            text="No networks scanned yet",
            font=("Arial", 10),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        self.summary_label.pack(side=tk.LEFT)
        
        # Export button
        self.export_button = tk.Button(
            summary_frame,
            text="Export Results",
            command=self.export_results,
            bg='#27ae60',
            fg='white',
            font=("Arial", 10),
            relief=tk.FLAT,
            padx=15,
            pady=5,
            state=tk.DISABLED
        )
        self.export_button.pack(side=tk.RIGHT)
        
    def start_scan(self):
        if self.scanning:
            return
            
        self.scanning = True
        self.scan_button.config(text="Scanning...", state=tk.DISABLED)
        self.status_label.config(text=f"Scanning for WiFi networks on {self.platform.title()}...")
        self.progress.start()
        
        # Clear previous results
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Start scanning in a separate thread
        scan_thread = threading.Thread(target=self.scan_networks)
        scan_thread.daemon = True
        scan_thread.start()
        
    def scan_networks(self):
        try:
            if self.platform == 'windows':
                networks = self.scan_windows()
            elif self.platform == 'linux':
                networks = self.scan_linux()
            elif self.platform == 'darwin':  # macOS
                networks = self.scan_macos()
            else:
                self.show_error(f"Unsupported platform: {self.platform}")
                return
            
            self.networks = networks
            self.root.after(0, self.display_results)
                
        except Exception as e:
            self.show_error(f"Error during scan: {str(e)}")
        finally:
            self.root.after(0, self.finish_scan)
    
    def scan_windows(self):
        """Scan networks on Windows using netsh"""
        try:
            result = subprocess.run(
                ['netsh', 'wlan', 'show', 'networks', 'mode=Bssid'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                raise Exception("Failed to execute netsh command")
            
            return self.parse_windows_output(result.stdout)
            
        except subprocess.TimeoutExpired:
            raise Exception("Scan timed out")
    
    def scan_linux(self):
        """Scan networks on Linux using iwlist or nmcli"""
        try:
            # Try iwlist first (more detailed output)
            try:
                result = subprocess.run(
                    ['iwlist', 'scan'],
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                if result.returncode == 0:
                    return self.parse_linux_iwlist_output(result.stdout)
            except FileNotFoundError:
                pass
            
            # Fallback to nmcli
            result = subprocess.run(
                ['nmcli', '-t', '-f', 'SSID,SECURITY,SIGNAL,CHAN,BSSID', 'device', 'wifi', 'list'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                raise Exception("Failed to execute network scanning command")
            
            return self.parse_linux_nmcli_output(result.stdout)
            
        except subprocess.TimeoutExpired:
            raise Exception("Scan timed out")
    
    def scan_macos(self):
        """Scan networks on macOS using airport command"""
        try:
            # Use airport command (requires sudo on some systems)
            airport_path = '/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport'
            
            result = subprocess.run(
                [airport_path, '-s'],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode != 0:
                raise Exception("Failed to execute airport command")
            
            return self.parse_macos_output(result.stdout)
            
        except subprocess.TimeoutExpired:
            raise Exception("Scan timed out")
    
    def parse_windows_output(self, output):
        """Parse Windows netsh output"""
        networks = []
        current_network = {}
        
        lines = output.split('\n')
        for line in lines:
            line = line.strip()
            
            if 'SSID' in line and 'BSSID' not in line:
                if current_network:
                    networks.append(current_network)
                current_network = {'ssid': line.split(':')[1].strip() if ':' in line else 'Unknown'}
                
            elif 'Authentication' in line:
                current_network['security'] = line.split(':')[1].strip() if ':' in line else 'Unknown'
                
            elif 'Signal' in line:
                signal_text = line.split(':')[1].strip() if ':' in line else '0%'
                current_network['signal'] = signal_text
                
            elif 'Radio type' in line:
                current_network['radio_type'] = line.split(':')[1].strip() if ':' in line else 'Unknown'
                
            elif 'BSSID' in line:
                current_network['bssid'] = line.split(':')[1].strip() if ':' in line else 'Unknown'
        
        if current_network:
            networks.append(current_network)
        
        return networks
    
    def parse_linux_iwlist_output(self, output):
        """Parse Linux iwlist output"""
        networks = []
        current_cell = {}
        
        # Split by cell
        cells = output.split('Cell')
        
        for cell in cells[1:]:  # Skip first empty element
            lines = cell.split('\n')
            current_cell = {}
            
            for line in lines:
                line = line.strip()
                
                if 'ESSID:' in line:
                    essid = line.split('"')[1] if '"' in line else 'Unknown'
                    current_cell['ssid'] = essid
                    
                elif 'Encryption key:' in line:
                    encryption = line.split(':')[1].strip()
                    current_cell['security'] = 'Open' if encryption == 'off' else 'Encrypted'
                    
                elif 'IE: IEEE 802.11i' in line:
                    # Look for WPA/WPA2 information
                    if 'WPA' in line:
                        current_cell['security'] = 'WPA/WPA2'
                        
                elif 'Quality=' in line:
                    # Extract signal strength
                    quality_match = re.search(r'Quality=(\d+)/(\d+)', line)
                    if quality_match:
                        quality = int(quality_match.group(1))
                        max_quality = int(quality_match.group(2))
                        signal_percent = int((quality / max_quality) * 100)
                        current_cell['signal'] = f"{signal_percent}%"
                        
                elif 'Channel:' in line:
                    channel = line.split(':')[1].strip()
                    current_cell['channel'] = channel
                    
                elif 'Address:' in line:
                    bssid = line.split(':')[1].strip()
                    current_cell['bssid'] = bssid
            
            if current_cell:
                networks.append(current_cell)
        
        return networks
    
    def parse_linux_nmcli_output(self, output):
        """Parse Linux nmcli output"""
        networks = []
        
        lines = output.strip().split('\n')
        for line in lines:
            if line.strip():
                parts = line.split(':')
                if len(parts) >= 5:
                    network = {
                        'ssid': parts[0] if parts[0] != '*' else parts[0][1:],
                        'security': parts[1] if parts[1] else 'Unknown',
                        'signal': f"{parts[2]}%" if parts[2] else '0%',
                        'channel': parts[3] if parts[3] else 'Unknown',
                        'bssid': parts[4] if parts[4] else 'Unknown'
                    }
                    networks.append(network)
        
        return networks
    
    def parse_macos_output(self, output):
        """Parse macOS airport output"""
        networks = []
        
        lines = output.strip().split('\n')
        for line in lines[1:]:  # Skip header
            if line.strip():
                parts = line.split()
                if len(parts) >= 6:
                    network = {
                        'ssid': parts[0],
                        'bssid': parts[1],
                        'signal': f"{parts[2]}%",
                        'channel': parts[3],
                        'security': parts[6] if len(parts) > 6 else 'Unknown'
                    }
                    networks.append(network)
        
        return networks
    
    def display_results(self):
        # Clear existing items
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        unsecure_count = 0
        total_count = len(self.networks)
        
        for network in self.networks:
            ssid = network.get('ssid', 'Unknown')
            security = network.get('security', 'Unknown')
            signal = network.get('signal', '0%')
            channel = network.get('channel', 'Unknown')
            bssid = network.get('bssid', 'Unknown')
            
            # Determine risk level
            risk_level = self.assess_risk(security, signal, ssid)
            if risk_level == 'High':
                unsecure_count += 1
            
            # Add to treeview
            self.tree.insert('', tk.END, values=(
                ssid,
                security,
                signal,
                channel,
                risk_level,
                bssid
            ))
            
            # Color code based on risk
            if risk_level == 'High':
                self.tree.tag_configure('high_risk', background='#ff4d4d', foreground='white')
                self.tree.item(self.tree.get_children()[-1], tags=('high_risk',))
            elif risk_level == 'Medium':
                self.tree.tag_configure('medium_risk', background='#fff3e0')
                self.tree.item(self.tree.get_children()[-1], tags=('medium_risk',))
            elif risk_level == 'Low':
                self.tree.tag_configure('low_risk', background='#e0f7fa')
                self.tree.item(self.tree.get_children()[-1], tags=('low_risk',))
            elif risk_level == 'Very Low':
                self.tree.tag_configure('very_low_risk', background='#e8f5e9')
                self.tree.item(self.tree.get_children()[-1], tags=('very_low_risk',))
        
        # Update summary
        summary_text = f"Found {total_count} networks, {unsecure_count} highly unsecure (Open/WEP/Hidden)"
        self.summary_label.config(text=summary_text)
        
        # Enable export button
        self.export_button.config(state=tk.NORMAL)
    
    def assess_risk(self, security, signal, ssid=None):
        security_lower = security.lower() if security else ''
        ssid = ssid or ''
        # High risk - open networks, WEP, or hidden/unknown SSID
        if 'open' in security_lower or 'none' in security_lower or 'wep' in security_lower or not ssid.strip() or ssid.lower() == 'unknown':
            return 'High'
        # Medium risk - WPA (not WPA2/3)
        if re.search(r'\bwpa(?!2|3)\b', security_lower):
            return 'Medium'
        # Low risk - WPA2
        if 'wpa2' in security_lower:
            return 'Low'
        # Very low risk - WPA3
        if 'wpa3' in security_lower:
            return 'Very Low'
        return 'Unknown'
    
    def finish_scan(self):
        self.scanning = False
        self.scan_button.config(text="Start Scan", state=tk.NORMAL)
        self.status_label.config(text="Scan completed")
        self.progress.stop()
    
    def export_results(self):
        if not self.networks:
            messagebox.showwarning("No Data", "No scan results to export.")
            return
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"wifi_scan_results_{self.platform}_{timestamp}.json"
            
            export_data = {
                'scan_timestamp': datetime.now().isoformat(),
                'platform': self.platform,
                'total_networks': len(self.networks),
                'networks': []
            }
            
            for network in self.networks:
                risk_level = self.assess_risk(
                    network.get('security', 'Unknown'),
                    network.get('signal', '0%'),
                    network.get('ssid', 'Unknown')
                )
                
                export_data['networks'].append({
                    'ssid': network.get('ssid', 'Unknown'),
                    'security': network.get('security', 'Unknown'),
                    'signal_strength': network.get('signal', '0%'),
                    'channel': network.get('channel', 'Unknown'),
                    'bssid': network.get('bssid', 'Unknown'),
                    'risk_level': risk_level
                })
            
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2)
            
            messagebox.showinfo("Export Successful", f"Results exported to {filename}")
            
        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export results: {str(e)}")
    
    def show_error(self, message):
        self.root.after(0, lambda: messagebox.showerror("Error", message))

def main():
    root = tk.Tk()
    app = CrossPlatformWiFiScanner(root)
    
    # Configure styles
    style = ttk.Style()
    style.theme_use('clam')
    
    # Configure treeview colors
    style.configure("Treeview", 
                   background="#ffffff",
                   foreground="#2c3e50",
                   rowheight=25,
                   fieldbackground="#ffffff")
    
    style.configure("Treeview.Heading",
                   background="#34495e",
                   foreground="white",
                   relief="flat")
    
    root.mainloop()

if __name__ == "__main__":
    main() 